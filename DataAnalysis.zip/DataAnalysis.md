# Colin Duggan and Noemi Meraz Data Analysis


```python
# Basic Packages
from __future__ import division
import os
from datetime import datetime

# Web & file access
import requests
import io

# Plotting
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick

%pylab --no-import-all
%matplotlib inline

import seaborn as sns
sns.set(rc={'figure.figsize':(11.7,8.27)})
sns.set_context("talk")

import plotly.express as px
import plotly.graph_objects as go

from plotnine import ggplot, geom_point, aes, stat_smooth, facet_wrap
# Next line can import all of plotnine, but may overwrite things? Better import each function/object you need
#from plotnine import *

# Data
import pandas as pd
import numpy as np
from pandas_datareader import data, wb

# GIS & maps
import geopandas as gpd
gp = gpd
import georasters as gr
import geoplot as gplt
import geoplot.crs as gcrs
import mapclassify as mc
import textwrap

# Data Munging
from itertools import product, combinations
import difflib
import pycountry
import geocoder
from geonamescache.mappers import country
mapper = country(from_key='name', to_key='iso3')
mapper2 = country(from_key='iso3', to_key='iso')
mapper3 = country(from_key='iso3', to_key='name')

# Regressions & Stats
from scipy.stats import norm
import statsmodels.formula.api as smf
#from stargazer.stargazer import Stargazer, LineLocation

# Paths
pathout = './data/'

if not os.path.exists(pathout):
    os.mkdir(pathout)
    
pathgraphs = './graphs/'
if not os.path.exists(pathgraphs):
    os.mkdir(pathgraphs)
```

    Using matplotlib backend: MacOSX
    %pylab is deprecated, use %matplotlib inline and import the required libraries.
    Populating the interactive namespace from numpy and matplotlib


# Data


```python
from PIL import Image

Hightechexport = Image.open("/Users/colinduggan/Desktop/Data/Hightechexport.png");
Hightechexport #graph 1
```




    
![png](output_3_0.png)
    




```python
Individualsusingtheinternet = Image.open("/Users/colinduggan/Desktop/Data/Individualsusingtheinternet.png");
Individualsusingtheinternet #graph 2

```




    
![png](output_4_0.png)
    




```python
Map = Image.open("/Users/colinduggan/Desktop/Data/Map.png");
Map #graph 3
```




    
![png](output_5_0.png)
    




```python
Mobilecellularsubscriptions = Image.open("/Users/colinduggan/Desktop/Data/Mobilecellularsubscriptions.png");
Mobilecellularsubscriptions #graph 4
```




    
![png](output_6_0.png)
    




```python
SecureInternetServers = Image.open("/Users/colinduggan/Desktop/Data/SecureInternetServers.png");
SecureInternetServers #graph 5
```




    
![png](output_7_0.png)
    




```python
SecureInternetServersper1M = Image.open("/Users/colinduggan/Desktop/Data/SecureInternetServersper1M.png");
SecureInternetServersper1M #graph 6
```




    
![png](output_8_0.png)
    



### What does each graph depict and how does it help us answer out question?
Graph 1:
This graph is interesting because it would be assumed that the countries that produce the high technology products would be the ones exporting in actuality the upper middle income countries produce the most. This leads us to believe that the production and sale of the high technology items does not lead to increseased economic growth, other than direct GDP dollar effect. s

Graph 2:
The large difference in individual internet usage between high and low income countries might be one of the major causes for lack of economic growth in low income countries. 

Graph 3:
This graphs shows every device connected to the internet. We did not generate this graph, but this image perfectly shows the topography of technology. People who are connected to the internet are most likely located in North America, Europe, or the major cities around the rest of the world. 

Graph 4:
Mobile cellular subscriptions really begin in the 1990's. in 2020, the high income average for 100 people was 120 cell subscriptions. For low income the number is closer to 60 subsciptions. This demonstrates the discrepency in access to the technology and how more affluent countries have more opportunity to develop technology given their current level of technology.

Graph 5:
Graph 5 Shows the number of secure internet servers in the United States versus othe countries with various income levels. The United States had a rapid increase in secure internet servers after 2014 and continued to increase amount. for the same reasons as graph 6, the graph shows the gap in development that the United States has over other nations that are developing their own technology. 

Graph 6: 
Graph 6 Shows the number of secure internet servers per million people in the United States versus the various income brackets. After 2015, the number of servers began to increase exponentially in the United States. The high income conutries have slightly less than half of the servers that the US has and the other three income brackets have very minimal servers. Internet privacy allows for countries to protect themselves and their ideas. Higher income countries have a higher demand for digital security to protect assets compared to low income countries. 
